package com.VMS.app.controller;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Map;

import javax.imageio.ImageIO;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.VMS.app.javaanpr.Main;

@Controller
public class IndexController {

	@RequestMapping("/")
	public String home(Map<String, Object> model) {
		model.put("message", "Vehicle management system Reader !!");
		return "next";
	}
	
	@RequestMapping("/errormapping")
	public String next(Map<String, Object> model) {
		model.put("message", "Exception occured");
		return "error";
	}
	
	/*
	 * @RequestMapping("/errormapping") public String next(Map<String, Object>
	 * model) { model.put("message", "Exception occured"); return "error"; }
	 */
	
	

	@PostMapping("/processImage")
	public String processImage(@RequestParam("imageFile") MultipartFile imageFile,Map<String, Object> model) throws IOException {
		
		if(imageFile !=null)
		{
		String name = imageFile.getOriginalFilename();
		System.out.println("file name is"+name);
		String NumberPlate = Main.main(imageFile);
		model.put("message", NumberPlate);
		BufferedImage imBuff = ImageIO.read(imageFile.getInputStream());
		File outputfile = new File("image.jpg");
		ImageIO.write(imBuff, "jpg", outputfile);
		String path = outputfile.getAbsolutePath();
		System.out.println("print the path "+path);
		model.put("imagepath", path);
		System.out.println("number plate "+model.get("message"));
		if (NumberPlate.length() == 0 || NumberPlate == null || NumberPlate.isEmpty()) {
			return "errormapping";	
		}
		
		return "next";
		}
		else
		{
			
			return "errormapping";	
			
		}
	}
	
}