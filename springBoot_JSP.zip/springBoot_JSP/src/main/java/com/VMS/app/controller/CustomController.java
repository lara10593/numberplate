package com.VMS.app.controller;

import java.util.Map;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

@ControllerAdvice
public class CustomController extends RuntimeException  {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@ExceptionHandler(Exception.class)
	public ModelAndView ErrorHandler(Exception e,Map<String, Object> model)
	
	{
		System.out.println("inside ErrorHandler");
		model.put("message", "User defined exceptions");
		return new ModelAndView("error");
		
	}

}
