package com.VMS.app.controller;

import java.io.IOException;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.VMS.app.javaanpr.Main;

@Controller
public class IndexController {

	@RequestMapping("/next")
	public String home(Map<String, Object> model) {
		model.put("message", "Vehicle management system Reader !!");
		return "index";
	}
	
	@RequestMapping("/")
	public String next(Map<String, Object> model) {
		model.put("message", "Please select a image to be proceed !!");
		return "next";
	}

	@PostMapping("/processImage")
	public String processImage(@RequestParam("imageFile") MultipartFile imageFile,Map<String, Object> model) throws IOException {
		
		String name = imageFile.getOriginalFilename();
		System.out.println("file name is"+name);
		
		String NumberPlate = Main.main(imageFile);
		model.put("message", NumberPlate);
		System.out.println("number plate "+model.get("message"));
		if (NumberPlate==null) {
			return "error";	
		}
		
		return "next";
	
		
		
		 
		
	}
	
}